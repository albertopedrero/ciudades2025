const express = require('express')
const CiudadesService = require('../servicios/ciudadesService')

function ciudadesAPI(app){
    const router = express.Router()
    app.use('/api/ciudades', router)

    const ciudadesService = new CiudadesService()


    router.get('/', async function (req, res, next){
        try{
            const ciudades = await ciudadesService.getCiudades()
            res.status(200).json(
                {
                    data: ciudades,
                    message: 'ciudades recuperadas con éxito'
                }
            )
        } catch(err){
            console.log(`se produjo un error ${err}`)
        } 
    })
}

module.exports = ciudadesAPI