const fs = require('fs')
class CiudadesService{

    async getCiudades(){
        let data = await fs.promises.readFile("./utils/mocks/ciudades.json");
        return JSON.parse(data);
    }

    
} 

module.exports = CiudadesService