const express = require('express')
const app = express()
const ciudadesAPI =require('./rutas/ciudades')

app.use(express.json());
app.use(express.urlencoded({extended: true}));

ciudadesAPI(app)

var server = app.listen('8080', () => {
    console.log(`servidor escuchando en ${server.address().port}`)
})

